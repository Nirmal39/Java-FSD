public interface First {
	
	public default void show() {
		System.out.println("This is my first  interface method");
	}

}