
import java.util.*;
public class Stack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<String> s=new Stack<String>();
		s.push("dmm");
		s.push("atp");
		s.push("AP");
		System.out.println(s);
		s.pop();
		System.out.println(s);
	}

}
