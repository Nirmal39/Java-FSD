
import .*;


public class Protectedchild extends ProtectedAnimal {
	public static void main(String[] args) {
		Protectedchild obj = new Protectedchild();   
	       obj.display();  
	}
	

}
