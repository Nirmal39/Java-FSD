

public class Publicspecifier {
	    public int myPublicVariable;
	    
	    public void myPublicMethod() {
	        System.out.println("This is a public method");
	    }
	}


